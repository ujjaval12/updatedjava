package Servlet;

import conn.DBconnection;
import model.Event;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; // Import HttpSession
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "HomeServlet", urlPatterns = {"/home", ""})
public class HomeServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(HomeServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        LOGGER.info("HomeServlet processing GET request for homepage...");
        HttpSession session = request.getSession(false);
        Integer userId = (session != null) ? (Integer) session.getAttribute("userId") : null;

        List<model.Event> upcomingEvents = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmtEvents = null;
        ResultSet rsEvents = null;
        String dbError = null;
        int unreadCount = 0;

        try {
            conn = DBconnection.getConnection();
            if (conn == null) {
                dbError = "Database connection failed.";
                LOGGER.severe("Failed to get database connection for HomeServlet.");
            } else {
                // --- Fetch upcoming events ---
                String sqlEvents = "SELECT event_id, title, event_date, event_time, location, description, image_filename FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC, event_time ASC LIMIT 6";
                pstmtEvents = conn.prepareStatement(sqlEvents);
                rsEvents = pstmtEvents.executeQuery();
                LocalDateTime now = LocalDateTime.now(ZoneId.systemDefault());
                while (rsEvents.next()) {
                    model.Event event = new model.Event();
                    event.setEventId(rsEvents.getInt("event_id")); event.setTitle(rsEvents.getString("title"));
                    java.sql.Date sqlDate = rsEvents.getDate("event_date"); java.sql.Time sqlTime = rsEvents.getTime("event_time");
                    LocalDate eventLocalDate = null; LocalTime eventLocalTime = null;
                    if (sqlDate != null) { event.setEventDate(new java.util.Date(sqlDate.getTime())); eventLocalDate = sqlDate.toLocalDate(); }
                    if (sqlTime != null) { eventLocalTime = sqlTime.toLocalTime(); event.setEventTime(eventLocalTime); } else { eventLocalTime = LocalTime.MIDNIGHT; event.setEventTime(null); }
                    event.setLocation(rsEvents.getString("location")); event.setDescription(rsEvents.getString("description")); event.setImageFilename(rsEvents.getString("image_filename"));
                    String status = "Upcoming"; if (eventLocalDate != null) { LocalDateTime eventDateTime = eventLocalDate.atTime(eventLocalTime != null ? eventLocalTime : LocalTime.MIDNIGHT); if (eventDateTime.isBefore(now)) { status = "Finished"; } else if (eventLocalDate.isEqual(now.toLocalDate())) { status = "Today"; } } event.setDisplayStatus(status);
                    upcomingEvents.add(event);
                }
                rsEvents.close();
                pstmtEvents.close();
                LOGGER.info("Fetched " + upcomingEvents.size() + " upcoming events with status.");

                // Fetch Unread Notification Count
                if (userId != null) {
                    PreparedStatement pstmtCount = null; ResultSet rsCount = null;
                    try {
                        String sqlCount = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE";
                        pstmtCount = conn.prepareStatement(sqlCount);
                        pstmtCount.setInt(1, userId);
                        rsCount = pstmtCount.executeQuery();
                        if (rsCount.next()) { unreadCount = rsCount.getInt(1); }
                        LOGGER.fine("User ID " + userId + " has " + unreadCount + " unread notifications.");
                    } catch (SQLException e) { LOGGER.log(Level.WARNING, "Could not fetch unread notification count for user ID " + userId, e); }
                    finally { try { if (rsCount != null) rsCount.close(); } catch (SQLException e) {} try { if (pstmtCount != null) pstmtCount.close(); } catch (SQLException e) {} }
                }
            }
        } catch (SQLException e) { dbError = "Error fetching data."; LOGGER.log(Level.SEVERE, "SQL Error fetching homepage data", e); }
        catch(Exception e) { dbError = "An unexpected error occurred."; LOGGER.log(Level.SEVERE, "Unexpected error fetching homepage data", e); }
        finally {
            try { if (rsEvents != null && !rsEvents.isClosed()) rsEvents.close(); } catch (SQLException e) {}
            try { if (pstmtEvents != null && !pstmtEvents.isClosed()) pstmtEvents.close(); } catch (SQLException e) {}
        }

        if (dbError != null) { request.setAttribute("homeError", dbError); }
        request.setAttribute("upcomingEvents", upcomingEvents);
        request.setAttribute("unreadCount", unreadCount); // Pass count to JSP

        RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
        dispatcher.forward(request, response);
    }
    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { doGet(request, response); }
}