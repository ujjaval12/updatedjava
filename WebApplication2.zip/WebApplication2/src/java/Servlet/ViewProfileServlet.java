package Servlet;

import conn.DBconnection;
import model.User;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewProfileServlet")
public class ViewProfileServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(ViewProfileServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=Please+login+to+view+your+profile."); return;
        }
        Integer userId = (Integer) session.getAttribute("userId");

        User userProfile = null;
        String errorMsg = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int unreadCount = 0;

        try {
            conn = DBconnection.getConnection();
            if (conn == null) { errorMsg = "Database connection error."; LOGGER.severe("DB connection failed for ViewProfileServlet."); }
            else {
                // Fetch user details
                String sql = "SELECT id, name, email, profile_description, profile_image_filename FROM user WHERE id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, userId);
                rs = pstmt.executeQuery();
                if (rs.next()) {
                    userProfile = new User();
                    userProfile.setId(rs.getInt("id")); userProfile.setName(rs.getString("name")); userProfile.setEmail(rs.getString("email"));
                    userProfile.setProfileDescription(rs.getString("profile_description")); userProfile.setProfileImageFilename(rs.getString("profile_image_filename"));
                    LOGGER.info("Fetched profile for user ID: " + userId);
                } else { errorMsg = "Could not find profile information."; LOGGER.warning("Profile not found in DB for user ID: " + userId); }
                rs.close(); pstmt.close(); // Close user fetch resources

                 // Fetch Unread Notification Count
                PreparedStatement pstmtCount = null; ResultSet rsCount = null;
                try {
                    String sqlCount = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE";
                    pstmtCount = conn.prepareStatement(sqlCount);
                    pstmtCount.setInt(1, userId);
                    rsCount = pstmtCount.executeQuery();
                    if (rsCount.next()) { unreadCount = rsCount.getInt(1); }
                    LOGGER.fine("User ID " + userId + " has " + unreadCount + " unread notifications.");
                } catch (SQLException e) { LOGGER.log(Level.WARNING, "Could not fetch unread notification count for user ID " + userId, e); }
                finally { try { if (rsCount != null) rsCount.close(); } catch (SQLException e) {} try { if (pstmtCount != null) pstmtCount.close(); } catch (SQLException e) {} }

            }
        } catch (SQLException e) { errorMsg = "Error fetching profile data."; LOGGER.log(Level.SEVERE, "SQL error fetching profile for user ID: " + userId, e); }
        finally {
             try { if (rs != null && !rs.isClosed()) rs.close(); } catch (SQLException e) {}
             try { if (pstmt != null && !pstmt.isClosed()) pstmt.close(); } catch (SQLException e) {}
        }

        if (errorMsg != null) { request.setAttribute("profileError", errorMsg); }
        request.setAttribute("userProfile", userProfile);
        request.setAttribute("unreadCount", unreadCount); // Set count

        RequestDispatcher dispatcher = request.getRequestDispatcher("/profile.jsp");
        dispatcher.forward(request, response);
    }
     @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { doGet(request, response); }
}