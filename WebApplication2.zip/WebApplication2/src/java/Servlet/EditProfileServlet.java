package Servlet;

// ... (Keep all existing imports) ...
import conn.DBconnection;
import model.User;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.*;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;


@WebServlet("/EditProfileServlet")
@MultipartConfig
public class EditProfileServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(EditProfileServlet.class.getName());
    private static final String UPLOAD_DIR = "C:/petfesthub_uploads"; // CHANGE IF NEEDED

    // --- doGet method remains the same ---
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                // ... (Existing code to fetch profile and forward to edit_profile.jsp) ...
                 HttpSession session = request.getSession(false);
                if (session == null || session.getAttribute("userId") == null) { response.sendRedirect("login.jsp?error=Please+login+to+edit+profile."); return; }
                Integer userId = (Integer) session.getAttribute("userId");
                User userToEdit = null; String errorMsg = null; Connection conn = null; PreparedStatement pstmt = null; ResultSet rs = null;
                try {
                    conn = DBconnection.getConnection();
                    if (conn == null) { errorMsg = "Database connection error."; }
                    else {
                        String sql = "SELECT id, name, email, profile_description, profile_image_filename FROM user WHERE id = ?";
                        pstmt = conn.prepareStatement(sql);
                        pstmt.setInt(1, userId);
                        rs = pstmt.executeQuery();
                        if (rs.next()) {
                            userToEdit = new User();
                            userToEdit.setId(rs.getInt("id"));
                            userToEdit.setName(rs.getString("name"));
                            userToEdit.setEmail(rs.getString("email"));
                            userToEdit.setProfileDescription(rs.getString("profile_description"));
                            userToEdit.setProfileImageFilename(rs.getString("profile_image_filename"));
                        } else { errorMsg = "Could not find your profile data."; }
                    }
                } catch (SQLException e) { errorMsg = "Error fetching profile data."; LOGGER.log(Level.SEVERE, "SQL error fetching profile for edit, user ID: " + userId, e); }
                finally { try { if (rs != null) rs.close(); } catch (SQLException e) {} try { if (pstmt != null) pstmt.close(); } catch (SQLException e) {} }
                if (errorMsg != null) { request.setAttribute("errorMessage", errorMsg); }
                request.setAttribute("userProfile", userToEdit);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/edit_profile.jsp");
                dispatcher.forward(request, response);
            }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.jsp?error=Authentication+required."); return;
        }
        Integer userId = (Integer) session.getAttribute("userId");

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String profileDescription = request.getParameter("profileDescription");
        Part filePart = request.getPart("profileImage");
        String currentImageFilename = request.getParameter("currentImageFilename");

        String redirectPage = "ViewProfileServlet";
        String finalImageFilename = currentImageFilename; // Default to keeping the old one
        boolean deleteOldImage = false;
        boolean newImageUploaded = false; // Flag to track if new image was processed

        // Validation (remains same)
         if (name == null || name.trim().isEmpty()) { response.sendRedirect("EditProfileServlet?action=showForm&error=Name+cannot+be+empty."); return; }


        // --- Handle New Image Upload ---
        if (filePart != null && filePart.getSize() > 0) {
            String originalFileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            if (originalFileName != null && !originalFileName.trim().isEmpty()) {
                String extension = ""; int i = originalFileName.lastIndexOf('.');
                 if (i > 0) { extension = originalFileName.substring(i + 1).toLowerCase(); }
                 if (!extension.matches("jpg|jpeg|png|gif")) { response.sendRedirect("EditProfileServlet?action=showForm&error=Invalid+image+file+type."); return; }

                 String uniqueID = UUID.randomUUID().toString();
                 String sanitizedOriginal = originalFileName.replaceAll("[^a-zA-Z0-9.\\-]", "_");
                 finalImageFilename = uniqueID + "_" + sanitizedOriginal; // Set potential new filename
                 newImageUploaded = true; // Mark that we have a new file

                 File uploadDir = new File(UPLOAD_DIR);
                 if (!uploadDir.exists()) { if (!uploadDir.mkdirs()) { response.sendRedirect(redirectPage + "?error=Server+error+creating+directory."); return; } }
                 File uploadedFile = new File(uploadDir, finalImageFilename);
                 try (InputStream fileContent = filePart.getInputStream()) { Files.copy(fileContent, uploadedFile.toPath(), StandardCopyOption.REPLACE_EXISTING); }
                 catch (IOException e) { finalImageFilename = currentImageFilename; newImageUploaded = false; response.sendRedirect("EditProfileServlet?action=showForm&error=Error+saving+new+image."); return; }

                // Mark old image for deletion ONLY if a new one was successfully saved
                if (currentImageFilename != null && !currentImageFilename.isEmpty()) {
                    deleteOldImage = true;
                 }
            }
        }
        // --- End Image Upload ---


        // --- Update Database ---
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean updateSuccess = false;
        try {
            conn = DBconnection.getConnection();
            if (conn == null) { throw new SQLException("DB connection failed."); }

            String sql = "UPDATE user SET name = ?, profile_description = ?, profile_image_filename = ? WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, profileDescription);
            pstmt.setString(3, finalImageFilename); // Use new filename (or old one if no upload)
            pstmt.setInt(4, userId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                updateSuccess = true;
                LOGGER.info("Profile updated successfully for user ID " + userId);
                // Update session attributes immediately
                session.setAttribute("userName", name);
                // **** NEW: Update profile image filename in session ****
                session.setAttribute("profileImageFilename", finalImageFilename); // Store new or old filename
            } else {
                 response.sendRedirect("EditProfileServlet?action=showForm&error=Update+failed.+Profile+not+found."); return;
            }
        } catch (SQLException e) {
             LOGGER.log(Level.SEVERE, "SQL Error updating profile for user ID " + userId, e);
             response.sendRedirect("EditProfileServlet?action=showForm&error=Database+error+during+update."); return;
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { /* Log */ }
        }
        // --- End Database Update ---


        // --- Delete Old Image (Only AFTER successful DB update AND new image uploaded) ---
        if (updateSuccess && deleteOldImage) { // Check if delete is warranted
             File oldFile = new File(UPLOAD_DIR, currentImageFilename);
             try { if (oldFile.exists()) { if(oldFile.delete()) { LOGGER.info("Deleted old profile image: " + currentImageFilename); } else { LOGGER.warning("Could not delete old profile image: " + currentImageFilename); } } }
             catch (Exception e) { LOGGER.log(Level.SEVERE, "Error deleting old profile image: " + currentImageFilename, e); }
        }
        // --- End Delete Old Image ---

        // Redirect back to profile view page with success message
        response.sendRedirect(redirectPage + "?message=Profile+updated+successfully!");
    }
}