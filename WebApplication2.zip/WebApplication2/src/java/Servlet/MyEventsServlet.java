package Servlet;

import conn.DBconnection;
import model.Event;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; // Ensure imported
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

// ** Ensure this annotation exactly matches the navbar link href target **
@WebServlet("/MyEventsServlet")
public class MyEventsServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(MyEventsServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        // ** Authorization Check **
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=Please+login+to+view+your+events."); return;
        }
        Integer userId = (Integer) session.getAttribute("userId");

        LOGGER.info("Fetching events for user ID: " + userId);
        List<Event> myEvents = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String dbError = null;
        int unreadCount = 0;

        try {
            conn = DBconnection.getConnection();
            if (conn == null) { dbError = "Database connection error."; LOGGER.severe("DB connection failed for MyEventsServlet."); }
            else {
                // ** Fetch User's Participated Events **
                String sql = "SELECT e.event_id, e.title, e.event_date, e.event_time, e.location, e.image_filename " +
                             "FROM events e JOIN event_participants ep ON e.event_id = ep.event_id " +
                             "WHERE ep.user_id = ? ORDER BY e.event_date ASC, e.event_time ASC";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, userId);
                rs = pstmt.executeQuery();
                LocalDateTime now = LocalDateTime.now(ZoneId.systemDefault());

                while (rs.next()) {
                     Event event = new Event();
                     event.setEventId(rs.getInt("event_id")); event.setTitle(rs.getString("title"));
                     java.sql.Date sqlDate = rs.getDate("event_date"); java.sql.Time sqlTime = rs.getTime("event_time");
                     LocalDate eventLocalDate = null; LocalTime eventLocalTime = null;
                     if (sqlDate != null) { event.setEventDate(new java.util.Date(sqlDate.getTime())); eventLocalDate = sqlDate.toLocalDate(); }
                     if (sqlTime != null) { eventLocalTime = sqlTime.toLocalTime(); event.setEventTime(eventLocalTime); } else { eventLocalTime = LocalTime.MIDNIGHT; event.setEventTime(null); }
                     event.setLocation(rs.getString("location")); event.setImageFilename(rs.getString("image_filename"));
                     // Calculate status
                     String status = "Upcoming"; if (eventLocalDate != null) { LocalDateTime eventDateTime = eventLocalDate.atTime(eventLocalTime != null ? eventLocalTime : LocalTime.MIDNIGHT); if (eventDateTime.isBefore(now)) { status = "Finished"; } else if (eventLocalDate.isEqual(now.toLocalDate())) { status = "Today"; } } event.setDisplayStatus(status);
                     myEvents.add(event);
                }
                rs.close(); // Close after use
                pstmt.close(); // Close after use
                LOGGER.info("Found " + myEvents.size() + " events for user ID " + userId);

                // ** Fetch Unread Notification Count **
                PreparedStatement pstmtCount = null; ResultSet rsCount = null;
                try {
                    String sqlCount = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE";
                    pstmtCount = conn.prepareStatement(sqlCount);
                    pstmtCount.setInt(1, userId);
                    rsCount = pstmtCount.executeQuery();
                    if (rsCount.next()) { unreadCount = rsCount.getInt(1); }
                    LOGGER.fine("User ID " + userId + " has " + unreadCount + " unread notifications.");
                } catch (SQLException e) { LOGGER.log(Level.WARNING, "Could not fetch unread notification count for user ID " + userId, e); }
                finally { try { if (rsCount != null) rsCount.close(); } catch (SQLException e) {} try { if (pstmtCount != null) pstmtCount.close(); } catch (SQLException e) {} }
            }
        } catch (SQLException e) { dbError = "Error fetching registered events."; LOGGER.log(Level.SEVERE, "SQL Error fetching events for user ID " + userId, e); }
        finally { // Ensure primary resources are closed even if notification count fails
              try { if (rs != null && !rs.isClosed()) rs.close(); } catch (SQLException e) { /* Log */ }
              try { if (pstmt != null && !pstmt.isClosed()) pstmt.close(); } catch (SQLException e) { /* Log */ }
        }

        // Set attributes for JSP
        if (dbError != null) { request.setAttribute("error", dbError); }
        request.setAttribute("myEvents", myEvents);
        request.setAttribute("unreadCount", unreadCount);

        // Forward to JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("/my_events.jsp");
        dispatcher.forward(request, response);
    }

     @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { doGet(request, response); }
}