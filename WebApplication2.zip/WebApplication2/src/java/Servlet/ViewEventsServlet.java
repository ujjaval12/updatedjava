package Servlet;

import conn.DBconnection;
import model.Event;
import java.sql.Time;
import java.time.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; // Import HttpSession
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/ViewEventsServlet")
public class ViewEventsServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(ViewEventsServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        LOGGER.info("ViewEventsServlet processing GET request...");
        HttpSession session = request.getSession(false);
        Integer userId = (session != null) ? (Integer) session.getAttribute("userId") : null;

        List<model.Event> allEvents = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String dbError = null;
        int unreadCount = 0;

        try {
            conn = DBconnection.getConnection();
            if (conn == null) { dbError = "Database connection failed."; LOGGER.severe("DB connection failed for ViewEventsServlet."); }
            else {
                // Fetch ALL events
                String sql = "SELECT event_id, title, event_date, event_time, location, description, image_filename FROM events ORDER BY event_date ASC, event_time ASC";
                pstmt = conn.prepareStatement(sql);
                rs = pstmt.executeQuery();
                LocalDateTime now = LocalDateTime.now(ZoneId.systemDefault());

                while (rs.next()) {
                    // ... (Populate event bean and calculate displayStatus - same as HomeServlet) ...
                     model.Event event = new model.Event();
                     event.setEventId(rs.getInt("event_id")); event.setTitle(rs.getString("title"));
                     java.sql.Date sqlDate = rs.getDate("event_date"); java.sql.Time sqlTime = rs.getTime("event_time");
                     LocalDate eventLocalDate = null; LocalTime eventLocalTime = null;
                     if (sqlDate != null) { event.setEventDate(new java.util.Date(sqlDate.getTime())); eventLocalDate = sqlDate.toLocalDate(); }
                     if (sqlTime != null) { eventLocalTime = sqlTime.toLocalTime(); event.setEventTime(eventLocalTime); } else { eventLocalTime = LocalTime.MIDNIGHT; event.setEventTime(null); }
                     event.setLocation(rs.getString("location")); event.setDescription(rs.getString("description")); event.setImageFilename(rs.getString("image_filename"));
                     String status = "Upcoming"; if (eventLocalDate != null) { LocalDateTime eventDateTime = eventLocalDate.atTime(eventLocalTime != null ? eventLocalTime : LocalTime.MIDNIGHT); if (eventDateTime.isBefore(now)) { status = "Finished"; } else if (eventLocalDate.isEqual(now.toLocalDate())) { status = "Today"; } } event.setDisplayStatus(status);
                     allEvents.add(event);
                }
                rs.close();
                pstmt.close();
                LOGGER.info("Fetched " + allEvents.size() + " total events with status.");

                 // Fetch Unread Notification Count
                 if (userId != null) {
                     PreparedStatement pstmtCount = null; ResultSet rsCount = null;
                     try {
                         String sqlCount = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE";
                         pstmtCount = conn.prepareStatement(sqlCount);
                         pstmtCount.setInt(1, userId);
                         rsCount = pstmtCount.executeQuery();
                         if (rsCount.next()) { unreadCount = rsCount.getInt(1); }
                         LOGGER.fine("User ID " + userId + " has " + unreadCount + " unread notifications.");
                     } catch (SQLException e) { LOGGER.log(Level.WARNING, "Could not fetch unread notification count for user ID " + userId, e); }
                     finally { try { if (rsCount != null) rsCount.close(); } catch (SQLException e) {} try { if (pstmtCount != null) pstmtCount.close(); } catch (SQLException e) {} }
                 }
            }
        } catch (SQLException e) { dbError = "Error fetching events."; LOGGER.log(Level.SEVERE, "SQL Error fetching all events", e); }
        catch (Exception e) { dbError = "An unexpected error occurred."; LOGGER.log(Level.SEVERE, "Unexpected error fetching all events", e); }
        finally {
             try { if (rs != null && !rs.isClosed()) rs.close(); } catch (SQLException e) {}
             try { if (pstmt != null && !pstmt.isClosed()) pstmt.close(); } catch (SQLException e) {}
        }

        if (dbError != null) { request.setAttribute("eventsError", dbError); }
        request.setAttribute("allEvents", allEvents);
        request.setAttribute("unreadCount", unreadCount); // Set count

        RequestDispatcher dispatcher = request.getRequestDispatcher("/events.jsp");
        dispatcher.forward(request, response);
    }
     @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { doGet(request, response); }
}