package Servlet;

import conn.DBconnection;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ApproveEventServlet")
public class ApproveEventServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(ApproveEventServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("isAdmin") == null || !((Boolean) session.getAttribute("isAdmin"))) {
            response.sendRedirect("login.jsp?adminError=Authentication+required."); return;
        }

        String requestIdStr = request.getParameter("requestId");
        String redirectPage = "AdminDashboardServlet";
        int requestId;
        try { requestId = Integer.parseInt(requestIdStr); }
        catch (NumberFormatException | NullPointerException e) { response.sendRedirect(redirectPage + "?error=Invalid+request+ID."); return; }

        Connection conn = null;
        PreparedStatement selectStmt = null;
        PreparedStatement insertStmt = null;
        PreparedStatement updateStmt = null;
        ResultSet rs = null;
        int newlyCreatedEventId = -1;
        String eventTitleForNotification = null;

        try {
            conn = DBconnection.getConnection();
            if (conn == null) { response.sendRedirect(redirectPage + "?error=Database+connection+failed."); return; }

            conn.setAutoCommit(false); // Start transaction

            String selectSql = "SELECT event_name, location, requested_date, requested_time, description, image_filename FROM event_requests WHERE request_id = ? AND status = ?";
            selectStmt = conn.prepareStatement(selectSql);
            selectStmt.setInt(1, requestId);
            selectStmt.setString(2, "PENDING");
            rs = selectStmt.executeQuery();

            if (rs.next()) {
                String eventName = rs.getString("event_name");
                eventTitleForNotification = eventName;
                String location = rs.getString("location");
                Date eventDate = rs.getDate("requested_date");
                Time eventTime = rs.getTime("requested_time");
                String description = rs.getString("description");
                String imageFilename = rs.getString("image_filename");

                String insertSql = "INSERT INTO events (title, event_date, event_time, location, description, image_filename) VALUES (?, ?, ?, ?, ?, ?)";
                insertStmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);
                insertStmt.setString(1, eventName);
                insertStmt.setDate(2, eventDate);
                insertStmt.setTime(3, eventTime);
                insertStmt.setString(4, location);
                insertStmt.setString(5, description);
                insertStmt.setString(6, imageFilename);
                int insertRows = insertStmt.executeUpdate();

                if (insertRows > 0) {
                    try (ResultSet generatedKeys = insertStmt.getGeneratedKeys()) {
                        if (generatedKeys.next()) { newlyCreatedEventId = generatedKeys.getInt(1); }
                        else { throw new SQLException("Creating event failed, no ID obtained."); }
                    }
                    String updateSql = "UPDATE event_requests SET status = ? WHERE request_id = ?";
                    updateStmt = conn.prepareStatement(updateSql);
                    updateStmt.setString(1, "APPROVED");
                    updateStmt.setInt(2, requestId);
                    int updateRows = updateStmt.executeUpdate();

                    if (updateRows > 0) {
                        conn.commit(); // Commit successful transaction
                        LOGGER.info("Event request ID " + requestId + " approved. Event created: " + eventName + " with ID: " + newlyCreatedEventId);
                        // Send Notifications AFTER commit
                        if (newlyCreatedEventId > 0) {
                             sendNewEventNotifications(newlyCreatedEventId, eventTitleForNotification);
                        } else { LOGGER.warning("Skipping notifications, failed to get new event ID."); }
                        response.sendRedirect(redirectPage + "?message=Event+approved+successfully!");
                    } else { conn.rollback(); LOGGER.severe("DB ERROR: Failed to update request status ID: " + requestId); response.sendRedirect(redirectPage + "?error=Failed+to+update+request+status."); }
                } else { conn.rollback(); LOGGER.severe("DB ERROR: Failed to insert event for request ID: " + requestId); response.sendRedirect(redirectPage + "?error=Failed+to+create+event+from+request."); }
            } else { conn.rollback(); LOGGER.warning("Approve attempt on non-existent/processed request ID: " + requestId); response.sendRedirect(redirectPage + "?error=Request+not+found+or+already+processed."); }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL Error during event approval transaction for request ID: " + requestId, e);
             try { if (conn != null) conn.rollback(); } catch (SQLException ex) { LOGGER.log(Level.SEVERE, "Failed to rollback transaction", ex); }
            response.sendRedirect(redirectPage + "?error=Database+error+during+approval.");
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) { /* Log */ }
            try { if (selectStmt != null) selectStmt.close(); } catch (SQLException e) { /* Log */ }
            try { if (insertStmt != null) insertStmt.close(); } catch (SQLException e) { /* Log */ }
            try { if (updateStmt != null) updateStmt.close(); } catch (SQLException e) { /* Log */ }
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) { /* Log */ }
        }
    } // End doPost

    /** Helper to send notifications */
    private void sendNewEventNotifications(int eventId, String eventTitle) {
        List<Integer> userIds = new ArrayList<>();
        Connection conn = null; PreparedStatement pstmtUsers = null; ResultSet rsUsers = null; PreparedStatement pstmtNotify = null;
        LOGGER.info("Attempting to send notifications for new event ID: " + eventId);
        try {
            conn = DBconnection.getConnection();
            if (conn == null) { LOGGER.severe("Cannot send notifications: DB connection failed."); return; }

            String sqlUsers = "SELECT id FROM user"; // Fetch all user IDs
            pstmtUsers = conn.prepareStatement(sqlUsers);
            rsUsers = pstmtUsers.executeQuery();
            while (rsUsers.next()) { userIds.add(rsUsers.getInt("id")); }
            rsUsers.close(); pstmtUsers.close(); // Close immediately

            LOGGER.info("Found " + userIds.size() + " users to notify about event ID " + eventId);
            if (!userIds.isEmpty()) {
                 String sqlNotify = "INSERT INTO notifications (user_id, message, link_url) VALUES (?, ?, ?)";
                 pstmtNotify = conn.prepareStatement(sqlNotify);
                 String safeTitle = eventTitle != null ? eventTitle.replaceAll("['\"<>&]", "") : "New Event"; // Basic sanitize
                 String message = "New event approved: '" + safeTitle + "'! Check it out.";
                 String link = "ViewEventsServlet"; // Link to general events page

                 for (int userId : userIds) {
                     pstmtNotify.setInt(1, userId);
                     pstmtNotify.setString(2, message);
                     pstmtNotify.setString(3, link);
                     pstmtNotify.addBatch();
                 }
                 int[] results = pstmtNotify.executeBatch();
                 LOGGER.info("Executed notification batch insert for event ID " + eventId + ". Result count: " + results.length);
            }
        } catch (SQLException e) { LOGGER.log(Level.SEVERE, "SQL Error sending new event notifications for event ID " + eventId, e); }
        finally {
             try { if (rsUsers != null && !rsUsers.isClosed()) rsUsers.close(); } catch (SQLException e) { /* Log */ }
             try { if (pstmtUsers != null && !pstmtUsers.isClosed()) pstmtUsers.close(); } catch (SQLException e) { /* Log */ }
             try { if (pstmtNotify != null && !pstmtNotify.isClosed()) pstmtNotify.close(); } catch (SQLException e) { /* Log */ }
             // Do not close shared connection
        }
    } // End sendNewEventNotifications
} // End Class