package Servlet;

import conn.DBconnection;
import model.Notification;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewNotificationsServlet")
public class ViewNotificationsServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(ViewNotificationsServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
             response.sendRedirect(request.getContextPath() + "/login.jsp?error=Please+login+to+view+notifications.");
             return;
        }
        Integer userId = (Integer) session.getAttribute("userId");

        LOGGER.info("Fetching notifications for user ID: " + userId);
        List<Notification> notifications = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmtSelect = null;
        ResultSet rs = null;
        PreparedStatement pstmtUpdate = null;
        String dbError = null;
        int initialUnreadCount = 0; // To check if update was needed

        try {
            conn = DBconnection.getConnection();
            if (conn == null) { dbError = "Database connection failed."; LOGGER.severe("DB connection failed."); }
            else {
                conn.setAutoCommit(false); // Use transaction

                // 1. Select notifications
                String sqlSelect = "SELECT notification_id, user_id, message, link_url, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
                pstmtSelect = conn.prepareStatement(sqlSelect);
                pstmtSelect.setInt(1, userId);
                rs = pstmtSelect.executeQuery();

                List<Integer> idsToMarkRead = new ArrayList<>();
                while (rs.next()) {
                    Notification notif = new Notification();
                    notif.setNotificationId(rs.getInt("notification_id"));
                    notif.setUserId(rs.getInt("user_id"));
                    notif.setMessage(rs.getString("message"));
                    notif.setLinkUrl(rs.getString("link_url"));
                    boolean isRead = rs.getBoolean("is_read");
                    notif.setRead(isRead); // Set initial read status
                    notif.setCreatedAt(rs.getTimestamp("created_at"));
                    notifications.add(notif);
                    if (!isRead) { idsToMarkRead.add(notif.getNotificationId()); }
                }
                initialUnreadCount = idsToMarkRead.size();
                rs.close(); pstmtSelect.close();
                LOGGER.info("Fetched " + notifications.size() + " notifications ("+initialUnreadCount+" unread) for user ID " + userId);

                // 2. Mark fetched as read
                if (!idsToMarkRead.isEmpty()) {
                     StringBuilder sqlUpdateBuilder = new StringBuilder("UPDATE notifications SET is_read = TRUE WHERE user_id = ? AND notification_id IN (");
                     for (int i = 0; i < idsToMarkRead.size(); i++) { sqlUpdateBuilder.append("?").append(i < idsToMarkRead.size() - 1 ? "," : ""); }
                     sqlUpdateBuilder.append(")");
                     pstmtUpdate = conn.prepareStatement(sqlUpdateBuilder.toString());
                     pstmtUpdate.setInt(1, userId);
                     int paramIndex = 2;
                     for (Integer id : idsToMarkRead) { pstmtUpdate.setInt(paramIndex++, id); }
                     int updatedRows = pstmtUpdate.executeUpdate();
                     pstmtUpdate.close();
                     LOGGER.info("Marked " + updatedRows + " notifications as read in DB for user ID " + userId);
                }

                conn.commit(); // Commit select + update
            }
        } catch (SQLException e) {
            dbError = "Error fetching/updating notifications.";
            LOGGER.log(Level.SEVERE, "SQL Error processing notifications for user ID " + userId, e);
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { LOGGER.log(Level.SEVERE, "Rollback failed", ex); }
        } finally {
            try { if (rs != null && !rs.isClosed()) rs.close(); } catch (SQLException e) {}
            try { if (pstmtSelect != null && !pstmtSelect.isClosed()) pstmtSelect.close(); } catch (SQLException e) {}
            try { if (pstmtUpdate != null && !pstmtUpdate.isClosed()) pstmtUpdate.close(); } catch (SQLException e) {}
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) {}
        }

        if (dbError != null) { request.setAttribute("error", dbError); }
        request.setAttribute("notifications", notifications);
        // Set unread count to 0 AFTER marking read for immediate navbar update if user navigates away
        request.setAttribute("unreadCount", 0);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/notifications.jsp");
        dispatcher.forward(request, response);
    }
}