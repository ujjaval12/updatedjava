package Servlet;

import conn.DBconnection;
import model.Event;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.*; // Import Time
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig; // Needed for file upload on POST
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/EditEventServlet")
@MultipartConfig // Handle potential file uploads during update
public class EditEventServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(EditEventServlet.class.getName());
    // !!! --- IMPORTANT: SET THIS PATH (Must match others) --- !!!
    private static final String UPLOAD_DIR = "C:/petfesthub_uploads";

    // Handles GET requests (Show Edit Form)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        // Authorization Check: Admin only
        if (session == null || session.getAttribute("isAdmin") == null || !((Boolean) session.getAttribute("isAdmin"))) {
            response.sendRedirect("login.jsp?adminError=Authentication+required.");
            return;
        }

        String eventIdStr = request.getParameter("eventId");
        String action = request.getParameter("action"); // Expecting "showForm"

        // Basic validation
        if (!"showForm".equals(action) || eventIdStr == null || eventIdStr.trim().isEmpty()) {
            response.sendRedirect("AdminDashboardServlet?error=Invalid+edit+request.");
            return;
        }

        int eventId;
        try {
            eventId = Integer.parseInt(eventIdStr);
        } catch (NumberFormatException e) {
            response.sendRedirect("AdminDashboardServlet?error=Invalid+Event+ID+format.");
            return;
        }

        Event eventToEdit = null;
        String errorMsg = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBconnection.getConnection();
            if (conn == null) {
                errorMsg = "Database connection failed.";
            } else {
                String sql = "SELECT event_id, title, event_date, event_time, location, description, image_filename " +
                             "FROM events WHERE event_id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, eventId);
                rs = pstmt.executeQuery();

                if (rs.next()) {
                    eventToEdit = new Event();
                    eventToEdit.setEventId(rs.getInt("event_id"));
                    eventToEdit.setTitle(rs.getString("title"));
                    eventToEdit.setEventDate(rs.getDate("event_date")); // Keep as java.util.Date for form pre-fill
                    Time sqlTime = rs.getTime("event_time");
                    if (sqlTime != null) { eventToEdit.setEventTime(sqlTime.toLocalTime()); }
                    eventToEdit.setLocation(rs.getString("location"));
                    eventToEdit.setDescription(rs.getString("description"));
                    eventToEdit.setImageFilename(rs.getString("image_filename"));
                    LOGGER.info("Fetched event for editing: ID " + eventId);
                } else {
                    errorMsg = "Event+with+ID+" + eventId + "+not+found.";
                    LOGGER.warning("Event not found for editing: ID " + eventId);
                }
            }
        } catch (SQLException e) {
            errorMsg = "Error+fetching+event+details+for+editing.";
            LOGGER.log(Level.SEVERE, "SQL Error fetching event ID " + eventId + " for edit", e);
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) { /* Log */ }
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { /* Log */ }
            // Don't close shared connection
        }

        // Set attributes and forward to the edit JSP
        if (errorMsg != null) {
            request.setAttribute("errorMessage", errorMsg); // Use a specific key
        }
        request.setAttribute("event", eventToEdit); // Attribute name for the form
        RequestDispatcher dispatcher = request.getRequestDispatcher("/edit_event.jsp"); // Forward to new JSP
        dispatcher.forward(request, response);
    }

    // Handles POST requests (Process Submitted Edit Form)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        // Authorization Check: Admin only
        if (session == null || session.getAttribute("isAdmin") == null || !((Boolean) session.getAttribute("isAdmin"))) {
            response.sendRedirect("login.jsp?adminError=Authentication+required.");
            return;
        }

        request.setCharacterEncoding("UTF-8");

        // Retrieve all form parameters (including hidden eventId)
        String eventIdStr = request.getParameter("eventId");
        String title = request.getParameter("title");
        String location = request.getParameter("location");
        String dateStr = request.getParameter("date");
        String timeStr = request.getParameter("time");
        String description = request.getParameter("description");
        Part filePart = request.getPart("eventImage"); // Check for new image upload

        String redirectPage = "AdminDashboardServlet"; // Default redirect
        String newImageFilename = null;
        boolean deleteOldImage = false;
        String oldImageFilename = request.getParameter("currentImageFilename"); // Get existing filename if any

        int eventId;
        try {
            eventId = Integer.parseInt(eventIdStr);
        } catch (NumberFormatException | NullPointerException e) {
             response.sendRedirect(redirectPage + "?error=Invalid+Event+ID+during+update."); return;
        }

        // Basic Validation (similar to create event)
        if (title == null || title.trim().isEmpty() || /* ... other fields ... */ description == null || description.trim().isEmpty()) {
             // Redirect back to edit form with error AND eventId
            response.sendRedirect("EditEventServlet?action=showForm&eventId=" + eventId + "&error=Please+fill+all+required+fields.");
            return;
        }

        // --- Handle File Upload (if new file provided) ---
        if (filePart != null && filePart.getSize() > 0) {
            String originalFileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            if (originalFileName != null && !originalFileName.trim().isEmpty()) {
                // Validate extension
                String extension = ""; int i = originalFileName.lastIndexOf('.');
                 if (i > 0) { extension = originalFileName.substring(i + 1).toLowerCase(); }
                 if (!extension.matches("jpg|jpeg|png|gif")) {
                     response.sendRedirect("EditEventServlet?action=showForm&eventId=" + eventId + "&error=Invalid+image+file+type."); return;
                 }
                // Create unique filename
                 String uniqueID = UUID.randomUUID().toString();
                 String sanitizedOriginal = originalFileName.replaceAll("[^a-zA-Z0-9.\\-]", "_");
                 newImageFilename = uniqueID + "_" + sanitizedOriginal;
                // Save new file
                 File uploadDir = new File(UPLOAD_DIR);
                 if (!uploadDir.exists()) { if (!uploadDir.mkdirs()) { /* handle error */ response.sendRedirect(redirectPage + "?error=Server+error+creating+directory."); return; } }
                 File uploadedFile = new File(uploadDir, newImageFilename);
                 try (InputStream fileContent = filePart.getInputStream()) { Files.copy(fileContent, uploadedFile.toPath(), StandardCopyOption.REPLACE_EXISTING); }
                 catch (IOException e) { /* handle error */ newImageFilename = null; response.sendRedirect("EditEventServlet?action=showForm&eventId=" + eventId + "&error=Error+saving+new+image."); return; }

                 // Mark old image for deletion if a new one was successfully saved
                 if (oldImageFilename != null && !oldImageFilename.isEmpty()) {
                    deleteOldImage = true;
                 }
                 LOGGER.info("New image uploaded for event ID " + eventId + ": " + newImageFilename);
            }
        } else {
            // No new file uploaded, keep the existing one
            newImageFilename = oldImageFilename;
             LOGGER.fine("No new image uploaded for event ID " + eventId + ". Keeping existing: " + oldImageFilename);
        }
        // --- End File Upload ---


        // --- Parse Date and Time ---
        java.sql.Date sqlDate = null;
        java.sql.Time sqlTime = null;
         try {
             SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
             dateFormat.setLenient(false);
             sqlDate = new java.sql.Date(dateFormat.parse(dateStr).getTime());

             LocalTime localTime = LocalTime.parse(timeStr);
             sqlTime = Time.valueOf(localTime);
         } catch (ParseException | DateTimeParseException | NullPointerException e) {
             LOGGER.warning("Invalid date/time format during update for event ID " + eventId);
             response.sendRedirect("EditEventServlet?action=showForm&eventId=" + eventId + "&error=Invalid+date+or+time+format.");
             return;
         }
        // --- End Parsing ---


        // --- Update Database ---
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBconnection.getConnection();
            if (conn == null) { response.sendRedirect(redirectPage + "?error=DB+Connection+failed."); return; }

            String sql = "UPDATE events SET title = ?, event_date = ?, event_time = ?, location = ?, " +
                         "description = ?, image_filename = ? WHERE event_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setDate(2, sqlDate);
            pstmt.setTime(3, sqlTime);
            pstmt.setString(4, location);
            pstmt.setString(5, description);
            pstmt.setString(6, newImageFilename); // Use the new (or old) filename
            pstmt.setInt(7, eventId);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                 LOGGER.info("Event ID " + eventId + " updated successfully.");
                 // ** Delete old image file AFTER successful DB update **
                 if (deleteOldImage && oldImageFilename != null && !oldImageFilename.isEmpty()) {
                     try {
                         File oldFile = new File(UPLOAD_DIR, oldImageFilename);
                         if (oldFile.exists()) {
                             if(oldFile.delete()) {
                                 LOGGER.info("Deleted old image file: " + oldImageFilename);
                             } else {
                                 LOGGER.warning("Could not delete old image file: " + oldImageFilename);
                             }
                         }
                     } catch (Exception e) { // Catch potential security exceptions etc.
                         LOGGER.log(Level.SEVERE, "Error deleting old image file: " + oldImageFilename, e);
                     }
                 }
                 response.sendRedirect(redirectPage + "?message=Event+ID+" + eventId + "+updated+successfully!");
            } else {
                 LOGGER.warning("Update failed for event ID " + eventId + ". Event might not exist.");
                 response.sendRedirect(redirectPage + "?error=Update+failed.+Event+not+found.");
            }

        } catch (SQLException e) {
             LOGGER.log(Level.SEVERE, "SQL Error updating event ID " + eventId, e);
             response.sendRedirect(redirectPage + "?error=Database+error+during+update.");
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { /* Log */ }
            // Don't close shared connection
        }
        // --- End Database Update ---
    }
}