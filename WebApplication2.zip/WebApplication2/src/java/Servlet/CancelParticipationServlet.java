package Servlet;

import conn.DBconnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/CancelParticipationServlet") // Matches link from my_events.jsp
public class CancelParticipationServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(CancelParticipationServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 1. Authorization Check: Must be a logged-in regular user
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=Please+login+to+manage+your+events.");
            return;
        }
        Integer userId = (Integer) session.getAttribute("userId");

        // 2. Get Event ID
        String eventIdStr = request.getParameter("eventId");
        String redirectPage = "MyEventsServlet"; // Redirect back to My Events list
        int eventId;

        if (eventIdStr == null || eventIdStr.trim().isEmpty()) {
            response.sendRedirect(redirectPage + "?error=Invalid+request%2C+missing+event+ID.");
            return;
        }
        try {
            eventId = Integer.parseInt(eventIdStr);
        } catch (NumberFormatException e) {
            response.sendRedirect(redirectPage + "?error=Invalid+event+ID+format.");
            return;
        }

        // 3. Attempt to Delete Participation Record
        Connection conn = null;
        PreparedStatement pstmt = null;
        String feedbackMessage = null;
        String feedbackType = "error"; // Default to error

        try {
            conn = DBconnection.getConnection();
            if (conn == null) {
                feedbackMessage = "Database+connection+failed.";
                LOGGER.severe("DB connection failed for CancelParticipationServlet.");
            } else {
                // Delete the specific participation record for this user and event
                String sql = "DELETE FROM event_participants WHERE event_id = ? AND user_id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, eventId);
                pstmt.setInt(2, userId);

                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    feedbackMessage = "Participation+cancelled+successfully.";
                    feedbackType = "message";
                    LOGGER.info("User ID " + userId + " cancelled participation for Event ID " + eventId);
                } else {
                    // Might happen if they tried to cancel twice quickly or record didn't exist
                    feedbackMessage = "Could+not+find+your+participation+record+to+cancel.";
                    LOGGER.warning("No participation record found to cancel for User ID " + userId + ", Event ID " + eventId);
                }
            }
        } catch (SQLException e) {
             feedbackMessage = "Database+error+while+cancelling+participation.";
             LOGGER.log(Level.SEVERE, "SQL Error cancelling participation for User ID " + userId + ", Event ID " + eventId, e);
         } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { /* Log */ }
            // Do not close shared connection
         }

         // 4. Redirect back to My Events list with feedback
         if(feedbackType.equals("error")) {
             response.sendRedirect(redirectPage + "?error=" + feedbackMessage);
        } else {
             response.sendRedirect(redirectPage + "?message=" + feedbackMessage);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         // If you change cancellation to use POST forms, handle it here.
         // For simple link clicking, GET is sufficient.
        doGet(request, response);
    }
}