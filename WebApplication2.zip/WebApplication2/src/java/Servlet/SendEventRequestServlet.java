package Servlet;

import conn.DBconnection;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time; // **** Required for setTime ****
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime; // **** Required for parsing time ****
import java.time.format.DateTimeParseException; // **** Required for time parsing errors ****
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/SendEventRequestServlet")
@MultipartConfig
public class SendEventRequestServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(SendEventRequestServlet.class.getName());
    // !!! --- IMPORTANT: SET THIS PATH --- !!!
    private static final String UPLOAD_DIR = "C:/petfesthub_uploads"; // Example: Windows

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
             response.sendRedirect(request.getContextPath() + "/login.jsp?error=Please+login+to+request+an+event.");
             return;
        }
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
             response.sendRedirect(request.getContextPath() + "/login.jsp?error=Session+error.+Please+login+again.");
             return;
        }

        request.setCharacterEncoding("UTF-8");

        // Retrieve all form parameters
        String eventName = request.getParameter("eventName");
        String location = request.getParameter("location");
        String dateStr = request.getParameter("date");
        String timeStr = request.getParameter("eventTime"); // **** Get time string ****
        String description = request.getParameter("description");
        Part filePart = request.getPart("eventImage");

        String redirectPage = "create-event.jsp";
        String finalUploadedFilename = null;

        // --- Text Field + Time Validation ---
        if (eventName == null || eventName.trim().isEmpty() ||
            location == null || location.trim().isEmpty() ||
            dateStr == null || dateStr.trim().isEmpty() ||
            timeStr == null || timeStr.trim().isEmpty() || // **** Validate time string ****
            description == null || description.trim().isEmpty()) {
            response.sendRedirect(redirectPage + "?error=Please+fill+in+all+required+fields%2C+including+time.");
            return;
        }

        // --- File Upload Processing ---
        if (filePart != null && filePart.getSize() > 0) {
            String originalFileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            if (originalFileName != null && !originalFileName.trim().isEmpty()) {
                 String extension = ""; int i = originalFileName.lastIndexOf('.');
                 if (i > 0) { extension = originalFileName.substring(i + 1).toLowerCase(); }
                 if (!extension.matches("jpg|jpeg|png|gif")) {
                     response.sendRedirect(redirectPage + "?error=Invalid+image+file+type."); return;
                 }
                 String uniqueID = UUID.randomUUID().toString();
                 String sanitizedOriginal = originalFileName.replaceAll("[^a-zA-Z0-9.\\-]", "_");
                 finalUploadedFilename = uniqueID + "_" + sanitizedOriginal;
                 File uploadDir = new File(UPLOAD_DIR);
                 if (!uploadDir.exists()) { if (!uploadDir.mkdirs()) { LOGGER.severe("FAILED TO CREATE UPLOAD DIR: "+UPLOAD_DIR); response.sendRedirect(redirectPage + "?error=Server+error+creating+directory."); return; } }
                 File uploadedFile = new File(uploadDir, finalUploadedFilename);
                 try (InputStream fileContent = filePart.getInputStream()) { Files.copy(fileContent, uploadedFile.toPath(), StandardCopyOption.REPLACE_EXISTING); LOGGER.info("File uploaded: " + uploadedFile.getAbsolutePath());}
                 catch (IOException e) { LOGGER.log(Level.SEVERE, "Error saving file", e); finalUploadedFilename = null; response.sendRedirect(redirectPage + "?error=Error+saving+file."); return; }
            }
        }

        // --- Date Parsing ---
        java.sql.Date sqlDate = null;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setLenient(false);
            sqlDate = new java.sql.Date(dateFormat.parse(dateStr).getTime());
        } catch (ParseException e) {
            LOGGER.warning("Invalid date format: " + dateStr);
            response.sendRedirect(redirectPage + "?error=Invalid+date+format.");
            return;
        }

        // --- Time Parsing ---
        LocalTime localTime = null;
        Time sqlTime = null;
        try {
            // HTML time input format is HH:mm or HH:mm:ss
            localTime = LocalTime.parse(timeStr); // java.time.LocalTime parses standard formats
            sqlTime = Time.valueOf(localTime); // Convert to java.sql.Time
        } catch (DateTimeParseException e) {
             LOGGER.warning("Invalid time format received: " + timeStr);
             response.sendRedirect(redirectPage + "?error=Invalid+time+format.+Please+use+HH%3Amm.");
             return;
        }

        // --- Database Insertion ---
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBconnection.getConnection();
            if (conn == null) {
                LOGGER.severe("DB connection failed for event request.");
                response.sendRedirect(redirectPage + "?error=DB+connection+error.");
                return;
            }

             // **** MODIFIED SQL: Added requested_time column ****
             String sql = "INSERT INTO event_requests " +
                          "(event_name, location, requested_date, requested_time, description, status, image_filename, requester_user_id) " + // Added requested_time
                          "VALUES (?, ?, ?, ?, ?, ?, ?, ?)"; // Added placeholder

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, eventName);
            pstmt.setString(2, location);
            pstmt.setDate(3, sqlDate);
            pstmt.setTime(4, sqlTime); // **** Use setTime with java.sql.Time ****
            pstmt.setString(5, description);
            pstmt.setString(6, "PENDING");
            pstmt.setString(7, finalUploadedFilename);
            pstmt.setInt(8, userId);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                 LOGGER.info("New event request submitted by User ID " + userId + ": " + eventName);
                 response.sendRedirect(redirectPage + "?message=Event+request+sent+successfully%21+An+admin+will+review+it.");
             } else {
                 LOGGER.warning("Event request DB insertion failed for: " + eventName);
                 response.sendRedirect(redirectPage + "?error=Failed+to+save+request.+Please+try+again.");
             }

        } catch (SQLException e) {
             LOGGER.log(Level.SEVERE, "SQL Error saving event request for user ID " + userId, e);
             response.sendRedirect(redirectPage + "?error=Database+error+during+request+submission.");
         } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Failed to close PreparedStatement", e); }
            // Do not close shared connection
        }
        // --- End Database Insertion ---
    }
}