package model;

import java.time.LocalTime; // Use java.time for time
import java.util.Date;

public class EventRequest {
    private int requestId;
    private String eventName;
    private String location;
    private Date requestedDate; // from java.sql.Date
    private LocalTime requestedTime; // **** NEW FIELD **** from java.sql.Time
    private String description;
    private String imageFilename;
    private String status;
    private Date requestedAt; // from java.sql.Timestamp
    private int requesterUserId;
    private String requesterName;
    private String requesterEmail;

    public EventRequest() {}

    // --- Getters and Setters ---
    public int getRequestId() { return requestId; }
    public void setRequestId(int requestId) { this.requestId = requestId; }
    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Date getRequestedDate() { return requestedDate; }
    public void setRequestedDate(Date requestedDate) { this.requestedDate = requestedDate; }
    public LocalTime getRequestedTime() { return requestedTime; } // **** NEW ****
    public void setRequestedTime(LocalTime requestedTime) { this.requestedTime = requestedTime; } // **** NEW ****
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getImageFilename() { return imageFilename; }
    public void setImageFilename(String imageFilename) { this.imageFilename = imageFilename; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Date getRequestedAt() { return requestedAt; }
    public void setRequestedAt(Date requestedAt) { this.requestedAt = requestedAt; }
    public int getRequesterUserId() { return requesterUserId; }
    public void setRequesterUserId(int requesterUserId) { this.requesterUserId = requesterUserId; }
    public String getRequesterName() { return requesterName; }
    public void setRequesterName(String requesterName) { this.requesterName = requesterName; }
    public String getRequesterEmail() { return requesterEmail; }
    public void setRequesterEmail(String requesterEmail) { this.requesterEmail = requesterEmail; }
}