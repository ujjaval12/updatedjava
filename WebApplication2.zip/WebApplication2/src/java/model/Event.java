package model;

import java.time.LocalTime; // Use java.time for time
import java.util.Date; // Keep using this for Date for now for compatibility with JDBC < 4.2 and JSTL 1.2 fmt tag

public class Event {
    private int eventId;
    private String title;
    private Date eventDate; // from java.sql.Date
    private LocalTime eventTime; // **** NEW FIELD **** from java.sql.Time
    private String location;
    private String description;
    private String imageFilename;
    private Date createdAt; // from java.sql.Timestamp

    // **** NEW: Transient status field (calculated in servlet) ****
    private String displayStatus;

    public Event() {}

    // --- Getters and Setters ---
    public int getEventId() { return eventId; }
    public void setEventId(int eventId) { this.eventId = eventId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public Date getEventDate() { return eventDate; }
    public void setEventDate(Date eventDate) { this.eventDate = eventDate; }
    public LocalTime getEventTime() { return eventTime; } // **** NEW ****
    public void setEventTime(LocalTime eventTime) { this.eventTime = eventTime; } // **** NEW ****
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getImageFilename() { return imageFilename; }
    public void setImageFilename(String imageFilename) { this.imageFilename = imageFilename; }
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
    public String getDisplayStatus() { return displayStatus; } // **** NEW ****
    public void setDisplayStatus(String displayStatus) { this.displayStatus = displayStatus; } // **** NEW ****

    @Override
    public String toString() {
        return "Event [eventId=" + eventId + ", title=" + title + ", eventDate=" + eventDate + ", eventTime=" + eventTime + ", location=" + location + "]";
    }
}