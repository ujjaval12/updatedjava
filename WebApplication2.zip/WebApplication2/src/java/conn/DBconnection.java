package conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBconnection {

    // --- Database Credentials ---
    private static final String DB_USER = "root"; // CHANGE IF YOUR MYSQL USER IS DIFFERENT
    private static final String DB_PASSWORD = "root"; // CHANGE IF YOUR MYSQL PASSWORD IS DIFFERENT
    // --- Database Name ---
    private static final String DB_NAME = "webappdb2"; // Choose your desired database name
    // --- JDBC URLs ---
    private static final String DB_URL_SERVER = "jdbc:mysql://localhost:3306/?user=" + DB_USER + "&password=" + DB_PASSWORD + "&sslMode=DISABLED";
    private static final String DB_URL_APP = "jdbc:mysql://localhost:3306/" + DB_NAME + "?user=" + DB_USER + "&password=" + DB_PASSWORD + "&sslMode=DISABLED";
    // --- Logger ---
    private static final Logger LOGGER = Logger.getLogger(DBconnection.class.getName());
    // --- Singleton Connection Instance ---
    private static volatile Connection connection = null;

    /**
     * Gets the singleton database connection. Initializes the database schema
     * if the connection hasn't been established yet. Includes basic checks
     * for existing connection validity.
     *
     * @return The Connection object, or null if initialization fails or connection is invalid.
     */
    public static Connection getConnection() {
        if (connection == null) {
            synchronized (DBconnection.class) {
                if (connection == null) {
                    try {
                        LOGGER.info("Attempting database initialization for " + DB_NAME + "...");
                        initializeDatabase(); // Assigns to static 'connection' if successful
                        LOGGER.info("Database connection established successfully to " + DB_NAME + ".");
                    } catch (Exception e) {
                        LOGGER.log(Level.SEVERE, "FATAL: Database initialization failed for " + DB_NAME + "!", e);
                        connection = null; // Ensure connection is null after failure
                        return null; // Indicate initialization failure
                    }
                }
            }
        } else {
             // Optional: Check if existing connection is still valid before returning it
             try {
                 if (connection.isClosed() || !connection.isValid(1)) { // Check if closed or invalid (timeout 1 sec)
                     LOGGER.warning("Existing database connection was closed or invalid. Attempting re-initialization...");
                     closeConnection(); // Close and nullify the static variable
                     return getConnection(); // Recursively call to re-initialize
                 }
             } catch (SQLException e) {
                 LOGGER.log(Level.SEVERE, "Error checking existing connection status. Attempting re-initialization...", e);
                 closeConnection(); // Close and nullify if check fails
                 return getConnection(); // Try to re-initialize
             }
        }
        return connection; // Return the valid (potentially new or existing) connection
    }

    /**
     * Initializes the database schema. Creates the database if it doesn't exist,
     * then connects to it and creates/updates necessary tables and constraints.
     * Uses a multi-pass approach for safety.
     */
    private static void initializeDatabase() throws ClassNotFoundException, SQLException {
        LOGGER.info("Loading MySQL JDBC driver (com.mysql.cj.jdbc.Driver)...");
        Class.forName("com.mysql.cj.jdbc.Driver");
        LOGGER.info("Driver loaded.");

        // Step 1: Create Database if needed (Uses temporary connection)
        LOGGER.info("Connecting to MySQL server to check/create database '" + DB_NAME + "'...");
        try (Connection tempConn = DriverManager.getConnection(DB_URL_SERVER);
             Statement stmt = tempConn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DB_NAME);
            LOGGER.info("Database '" + DB_NAME + "' checked/created.");
        }

        // Step 2: Connect to App Database and Initialize Schema
        Connection conn = null; // Local variable for setup
        Statement stmt = null;  // Reusable statement for initialization
        try {
            LOGGER.info("Connecting to application database: " + DB_NAME);
            conn = DriverManager.getConnection(DB_URL_APP);
            LOGGER.info("Connected successfully to database: " + DB_NAME + ".");
            stmt = conn.createStatement();

            // --- Pass 1: Create Base Tables ---
            LOGGER.info("Schema Initialization - Pass 1: Creating base tables...");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS user (" +
                               "id INT AUTO_INCREMENT PRIMARY KEY," +
                               "name VARCHAR(100) NOT NULL," +
                               "email VARCHAR(100) NOT NULL UNIQUE," +
                               "password VARCHAR(255) NOT NULL" +
                               ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            LOGGER.info("'user' table created if not exists.");

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS events (" +
                               "event_id INT AUTO_INCREMENT PRIMARY KEY," +
                               "title VARCHAR(255) NOT NULL," +
                               "event_date DATE," +
                               "description TEXT," +
                               "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                               ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            LOGGER.info("'events' table created if not exists.");

             stmt.executeUpdate("CREATE TABLE IF NOT EXISTS event_requests (" +
                                "request_id INT AUTO_INCREMENT PRIMARY KEY," +
                                "event_name VARCHAR(255) NOT NULL," +
                                "location VARCHAR(255)," +
                                "requested_date DATE," +
                                "description TEXT," +
                                "status VARCHAR(20) DEFAULT 'PENDING'," +
                                "requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
             LOGGER.info("'event_requests' table created if not exists.");

             stmt.executeUpdate("CREATE TABLE IF NOT EXISTS event_participants (" +
                                "registration_id INT AUTO_INCREMENT PRIMARY KEY," +
                                "event_id INT NOT NULL," +
                                "user_id INT NOT NULL," +
                                "registration_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                                "KEY idx_event_id (event_id)," +
                                "KEY idx_user_id (user_id)" +
                                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
             LOGGER.info("'event_participants' table created if not exists.");

             stmt.executeUpdate("CREATE TABLE IF NOT EXISTS notifications (" +
                                "notification_id INT AUTO_INCREMENT PRIMARY KEY," +
                                "user_id INT NOT NULL," + // Who is it for?
                                "message TEXT NOT NULL," +
                                "link_url VARCHAR(500) NULL," + // Optional link (e.g., to event)
                                "is_read BOOLEAN DEFAULT FALSE," +
                                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                                "KEY idx_user_read (user_id, is_read)," + // Index for fast unread count
                                "KEY idx_notification_user (user_id)" + // Index for FK
                                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            LOGGER.info("'notifications' table created if not exists.");


            // --- Pass 2: Add Columns via ALTER TABLE ---
            LOGGER.info("Schema Initialization - Pass 2: Adding columns...");
            addColumnIfNotExists(stmt, "user", "profile_description", "TEXT NULL");
            addColumnIfNotExists(stmt, "user", "profile_image_filename", "VARCHAR(255) NULL");
            addColumnIfNotExists(stmt, "events", "location", "VARCHAR(255) NULL");
            addColumnIfNotExists(stmt, "events", "image_filename", "VARCHAR(255) NULL");
            addColumnIfNotExists(stmt, "events", "event_time", "TIME NULL");
            addColumnIfNotExists(stmt, "event_requests", "image_filename", "VARCHAR(255) NULL");
            addColumnIfNotExists(stmt, "event_requests", "requester_user_id", "INT NULL");
            addColumnIfNotExists(stmt, "event_requests", "requested_time", "TIME NULL");


            // --- Pass 3: Add Foreign Keys and Unique Constraints ---
            LOGGER.info("Schema Initialization - Pass 3: Adding constraints...");
            addConstraintIfNotExists(stmt, "event_requests", "fk_requester_user", "FOREIGN KEY (requester_user_id) REFERENCES user(id) ON DELETE SET NULL");
            addConstraintIfNotExists(stmt, "event_participants", "fk_participant_event", "FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE");
            addConstraintIfNotExists(stmt, "event_participants", "fk_participant_user", "FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE");
            addConstraintIfNotExists(stmt, "event_participants", "unique_participation", "UNIQUE KEY unique_participation (event_id, user_id)");
            addConstraintIfNotExists(stmt, "notifications", "fk_notification_user", "FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE");

            LOGGER.info("Database schema initialization complete.");

            DBconnection.connection = conn; // Assign only on full success
            conn = null; // Prevent close in finally block below if successful

        } catch (SQLException e) {
             LOGGER.log(Level.SEVERE, "SQLException during database schema initialization!", e);
             if (conn != null) { try { conn.close(); } catch (SQLException ex) { LOGGER.log(Level.WARNING, "Failed to close connection during init cleanup", ex); } }
             DBconnection.connection = null;
             throw e;
        } finally {
             if (stmt != null) { try { stmt.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Failed to close init statement", e); } }
             if (conn != null) { try { conn.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Failed to close connection in init finally block (should not happen if successful)", e); } }
        }
    } // End initializeDatabase


    // Helper method to add column if it doesn't exist using information_schema
    private static void addColumnIfNotExists(Statement stmt, String tableName, String columnName, String columnDefinition) {
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery("SELECT 1 FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = '" + tableName + "' AND column_name = '" + columnName + "'");
            if (!rs.next()) { stmt.executeUpdate("ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + columnDefinition); LOGGER.info("Column '" + columnName + "' added successfully to table '" + tableName + "'."); }
            else { LOGGER.fine("Column '" + columnName + "' already exists in table '" + tableName + "'."); }
        } catch (SQLException e) { LOGGER.log(Level.WARNING, "Could not check/add column " + columnName + " for table " + tableName, e); }
        finally { if (rs != null) { try { rs.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Failed to close ResultSet in addColumnIfNotExists", e); } } }
    }

     // Helper method to add constraint if it doesn't exist using information_schema
    private static void addConstraintIfNotExists(Statement stmt, String tableName, String constraintName, String constraintDefinition) {
         ResultSet rs = null;
        try {
             rs = stmt.executeQuery("SELECT 1 FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = '" + tableName + "' AND constraint_name = '" + constraintName + "'");
             if (!rs.next()) { stmt.executeUpdate("ALTER TABLE " + tableName + " ADD " + constraintDefinition); LOGGER.info("Constraint '" + constraintName + "' added successfully to table '" + tableName + "'."); }
             else { LOGGER.fine("Constraint '" + constraintName + "' already exists on table '" + tableName + "'."); }
        } catch (SQLException e) {
             if (e.getErrorCode() == 1061 || e.getErrorCode() == 1826 || e.getMessage().contains("Duplicate key name") || e.getMessage().contains("already exists")) { LOGGER.fine("Ignoring duplicate constraint error for '" + constraintName + "' on table '" + tableName + "'."); }
             else { LOGGER.log(Level.WARNING, "Could not check/add constraint " + constraintName + " for table " + tableName, e); }
        } finally { if (rs != null) { try { rs.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Failed to close ResultSet in addConstraintIfNotExists", e); } } }
    }

    // Method to close connection
    public static void closeConnection() {
        synchronized (DBconnection.class) {
            Connection connToClose = DBconnection.connection;
            DBconnection.connection = null;
            if (connToClose != null) { try { if (!connToClose.isClosed()) { connToClose.close(); LOGGER.info("Database connection closed successfully."); } else { LOGGER.info("Database connection was already closed."); } } catch (SQLException e) { LOGGER.log(Level.SEVERE, "Error closing database connection", e); } }
            else { LOGGER.info("Database connection was already null."); }
        }
    }
}